public class PassaVez extends CasaTabuleiro{
	public PassaVez(int posicao)
	{
		super(posicao);
	}
}
