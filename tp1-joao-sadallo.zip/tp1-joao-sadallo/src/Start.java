public class Start extends CasaTabuleiro{
	public Start(int posicao)
	{
		super(posicao);
	}
}
