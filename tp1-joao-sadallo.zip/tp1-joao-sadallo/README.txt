
NOME:
Joao Paulo Martino Bregunci
Sadallo Andere Neto

src -> source code
bin -> arquivos de class
    -> Makefile
    -> bin -> jogadas.txt       // Le esse arquivo como entrada
           -> tabuleiro.txt     // Le esse arquivo como entrada
           -> outros arquivos utilizados
